<h2>This is a Responsive Real estate website landing page built using html, css and javascript</h2>
![real-estate-site](https://user-images.githubusercontent.com/65310505/234520907-3d084fd3-b05e-4e91-8a5d-0bb89758de80.png)



<p>Full tutorial available on youtube @Codemyhobby. https://www.youtube.com/watch?v=8f4lkXzwWDc</p>

